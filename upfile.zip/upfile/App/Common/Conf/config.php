<?php
return array(
	'SHOW_PAGE_TRACE' =>false, //显示调试页面
	'MODULE_ALLOW_LIST'    =>    array('Home','CAY_ADMIN','Admin'),//设置模块列表
    'DEFAULT_MODULE'       =>    'Home',//设置默认模块
    'URL_MODULE_MAP'       =>    array('cay_admin'=>'admin'),//模块映射

    //数据库配置信息
    'DB_TYPE'   => 'mysql', // 
    'DB_HOST'   => '10.68.150.169', 
    'DB_NAME'   => 'cay', // 数据库名
    'DB_USER'   => 'cay_f', // 用户��?
    'DB_PWD'    => '123456', // 密码
    'DB_PORT'   => 4003, // 端口
    'DB_PREFIX' => 'cay_', // 数据库表前缀
    'DB_CHARSET'=> 'utf8', // 字符��?

   
);