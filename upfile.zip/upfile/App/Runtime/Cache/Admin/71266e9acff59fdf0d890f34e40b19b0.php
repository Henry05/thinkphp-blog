<?php if (!defined('THINK_PATH')) exit();?><link rel="stylesheet" type="text/css" href="/W3CAY/Public/Admin/CSS/index.css">
<div class="readme">
<h1 class="index_title">安望云海-致力于Html/Css/Js/WEB开发</h1>
<h2 class="index_title">WWW.W3CAY.COM</h2>
<h3>配置信息</h3>
</div>